//
//  ContentView.swift
//  clima
//
//  Created by Apple on 7/18/22.
//

import SwiftUI

struct ContentView: View {
   
   
    @State var continued = false
    
    enum Tab {
        case Home
        case Events
        case Maps
        
}
    init () {
        UITabBar.appearance().backgroundColor = .white }
    var body: some View {
     
         
        ZStack{
        
            Image("backgroundPic")
                  .resizable()
                  .ignoresSafeArea()
            
        
            if continued {
                Home()
            }
            else{
            Button("< Back") {
                continued = true
            }
            .padding(10.0)
            .controlSize(/*@START_MENU_TOKEN@*/.large/*@END_MENU_TOKEN@*/)
            .offset(x:-140 , y:-360)
            .foregroundColor(.white)
            

            
            
            Text ("Today's Way to Get Involved")
                .font(.title3)
                .fontWeight(.light)
                .offset(x:-60 , y:-320 )
                .foregroundColor(Color.white)
            
                
            ZStack {
            
            
            
            
            Rectangle ()
                .padding(0.0)
                .foregroundColor(Color("grayGreen"))
                .frame (width:350.0, height: 400.0)
                .cornerRadius(/*@START_MENU_TOKEN@*/15.0/*@END_MENU_TOKEN@*/)
                .offset( y:-100 )
       Text ("Community Garden Planting")
            .font(.title)
            .fontWeight(.bold)
            .foregroundColor(Color.white)
            .multilineTextAlignment(.center)
            .frame(width: 300.0)
            .offset( y:-250)
            
       Text("@ Hermitage Street Community Garden      On July 14th from 7am to 12pm                        No RSVP                                                         Posted by Cathrine Peter")
                .font(.body)
                .fontWeight(.medium)
                .foregroundColor(Color.white)
                .frame(width: 330.0)
                .offset( y:-160)
        Text ("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea")
                .font(.body)
                .fontWeight(.bold)
                .foregroundColor(Color.white)
                .lineLimit(10)
                .frame(width: 330.0)
                .dynamicTypeSize(.xLarge)
                .offset( y:-20)
            
                Button("Attend ?") {
                    /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                }
                .padding(10.0)
                .controlSize(/*@START_MENU_TOKEN@*/.large/*@END_MENU_TOKEN@*/)
                .border(Color("darkSeaGreen"), width: /*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/)
                .offset(x:90 , y:70)
                .foregroundColor(.white)
            }
            
                ZStack{
            Rectangle ()
                    .foregroundColor(Color("grayGreen"))
                    .cornerRadius(/*@START_MENU_TOKEN@*/15.0/*@END_MENU_TOKEN@*/)
                    .frame (width:350.0, height: 100.0)
                    .offset( y:195)
            Text ("Other Events You May Like")
                .font(.headline)
                .fontWeight(.light)
                .offset(x:-80, y:125)
                .foregroundColor(Color.white)
                
                
            Text ("Youth Summit")
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(Color.white)
                .frame(width: 300.0)
                .offset(y:170)
            Text ("@ Millenium Park On August 14th from 4pm to 8 pm Posted by Hailey Rodgers")
                .font(.body)
                .fontWeight(.medium)
                .foregroundColor(Color.white)
                .frame(width: 330.0)
                .offset(y:215)
            }
           
             
            }

            TabView(selection: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Selection@*/.constant(1)/*@END_MENU_TOKEN@*/) {
                                   Home()
            .tabItem { Label("Home", systemImage: "house") }.tag(Tab.Home)
                                   Events()
            .tabItem { Label("Events", systemImage: "calendar") }.tag(Tab.Events)
                                   Maps()
            .tabItem { Label("Maps", systemImage: "map") }.tag(Tab.Maps)
                              }
        }

}
    
    
    
    
                
            
                
                
                
            
    
    




struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
    }
