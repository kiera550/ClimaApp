//
//  Events2.swift
//  clima
//
//  Created by Apple on 8/3/22.
//

import SwiftUI

struct Events2: View {
    var body: some View {
        ZStack{
        
            Image("backgroundPic")
                  .resizable()
                  .ignoresSafeArea()

            Rectangle ()
                .padding(0.0)
                .foregroundColor(Color("grayGreen"))
                .frame (width:350.0, height: 100.0)
                .cornerRadius(/*@START_MENU_TOKEN@*/15.0/*@END_MENU_TOKEN@*/)
                .offset(y:-280)
      
            Rectangle ()
                .foregroundColor (Color ("darkSeaGreen"))
                .frame(width: 350.0, height: 300.0)
                .cornerRadius(15.0)
                .offset( y: -60)
        
            Text ("Community Garden Planting")
            .font(.title)
            .fontWeight(.bold)
            .foregroundColor(Color.white)
            .multilineTextAlignment(.center)
            .frame(width: 300.0)
            .offset( y:-280)

      Text("Instructions :")
                .fontWeight(.medium)
                .foregroundColor(Color.black)
                .frame(width: 330.0)
                .offset(y:-180)
                .dynamicTypeSize(.xxxLarge)
            Text("@ Hermitage Street Community Garden                                                      On July 14th from 7am to 12pm                        No RSVP                                                         Posted by Cathrine Peter                  Meet in front of the main doors   Assignments will be given at 7:10 A.M         If lost or confused ask for Catherine Peter. ")
                .font(.body)
                .fontWeight(.medium)
                .foregroundColor(Color.black)
                .frame(width: 330.0)
                .offset( y:-50)
                .dynamicTypeSize(.xLarge)
            
            Rectangle ()
                .foregroundColor (Color ("laurelGreen"))
                .frame(width: 350.0, height: 150.0)
                .cornerRadius(15.0)
                .offset(y:190)
            
            Text("Requirements :")
                      .fontWeight(.medium)
                      .foregroundColor(Color.black)
                      .frame(width: 330.0)
                      .offset(y:140)
                      .dynamicTypeSize(.xxxLarge)
            
            Text("- Bring your own shovel                                   - Lunch will be provided at 12pm                 - 16 years +                                                       - Do not be late")
                .font(.body)
                .fontWeight(.medium)
                .foregroundColor(Color.black)
                .frame(width: 330.0)
                .offset( y:200)

        
        
        
        }
}

struct Events2_Previews: PreviewProvider {
    static var previews: some View {
        Events2()
    }
}
}
