//
//  Maps.swift
//  clima
//
//  Created by Apple on 8/5/22.
//

import SwiftUI

struct Maps: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Maps_Previews: PreviewProvider {
    static var previews: some View {
        Maps()
    }
}
