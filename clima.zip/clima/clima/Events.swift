//
//  Events.swift
//  clima
//
//  Created by Apple on 7/19/22.
//

import SwiftUI

struct Events: View {
    
//    @State var continued = false
    
    enum Tab {
        case Home
        case Events
        case Rewards
        
}
    
    var body: some View {
     
        NavigationView{
        ZStack{
        
            Image("backgroundPic")
                  .resizable()
                  .ignoresSafeArea()
            
            Text ("Today's Way to Get Involved")
                .font(.title3)
                .fontWeight(.light)
                .offset(x:-30 , y:-375 )
                .foregroundColor(Color.white)
                .dynamicTypeSize(.xxxLarge)

                
            ZStack {
            
            
            
            
            Rectangle ()
                .padding(0.0)
                .foregroundColor(Color("grayGreen"))
                .frame (width:350.0, height: 400.0)
                .cornerRadius(/*@START_MENU_TOKEN@*/15.0/*@END_MENU_TOKEN@*/)
                .offset( y:-150 )
       Text ("Community Garden Planting")
            .font(.title)
            .fontWeight(.bold)
            .foregroundColor(Color.white)
            .multilineTextAlignment(.center)
            .frame(width: 300.0)
            .offset( y:-300)
            
       Text("@ Hermitage Street Community Garden      On July 14th from 7am to 12pm                        No RSVP                                                         Posted by Cathrine Peter")
                .font(.body)
                .fontWeight(.medium)
                .foregroundColor(Color.white)
                .frame(width: 330.0)
                .offset( y:-220)
        Text ("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea")
                .font(.body)
                .fontWeight(.bold)
                .foregroundColor(Color.white)
                .lineLimit(10)
                .frame(width: 330.0)
                .dynamicTypeSize(.xLarge)
                .offset( y:-80)
            


                NavigationLink(destination: Events2(), label: {Text("Attend ?")
                }) .padding(10.0)
                    .controlSize(/*@START_MENU_TOKEN@*/.large/*@END_MENU_TOKEN@*/)
                    .border(Color("darkSeaGreen"), width: /*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/)
                    .offset(x:90 , y:10)
                    .foregroundColor(.white)
            
                ZStack{
            Rectangle ()
                    .foregroundColor(Color("grayGreen"))
                    .cornerRadius(/*@START_MENU_TOKEN@*/15.0/*@END_MENU_TOKEN@*/)
                    .frame (width:350.0, height: 150.0)
                    .offset( y:190)
            Text ("Other Events You May Like")
                .font(.headline)
                .fontWeight(.light)
                .offset(x:-55, y:90)
                .foregroundColor(Color.white)
                .dynamicTypeSize(.xxxLarge)
                
            Text ("Youth Summit")
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(Color.white)
                .frame(width: 300.0)
                .offset(y:140)
            Text ("@ Millenium Park On August 14th from 4pm to 8 pm Posted by Hailey Rodgers")
                .font(.body)
                .fontWeight(.medium)
                .foregroundColor(Color.white)
                .frame(width: 330.0)
                .offset(y:180)
                   
                    NavigationLink(destination: Events3(), label:{Text("Interested?")
//
                }).padding(10.0)
                    .controlSize(/*@START_MENU_TOKEN@*/.large/*@END_MENU_TOKEN@*/)
                    .border(Color("darkSeaGreen"), width: /*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/)
                    .offset(x:90 , y:230)
                    .foregroundColor(.white)
           
            
                
                
                
            


                }}        }
        } }
    }

struct Events_Previews: PreviewProvider {
    static var previews: some View {
        Events()
      } }

        


