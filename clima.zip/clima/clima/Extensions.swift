//
//  Extensions.swift
//  clima
//
//  Created by Apple on 7/18/22.
//

import Foundation
import SwiftUI

extension UIColor {
    static let darkGreen: UIColor = UIColor(named:"darkSeaGreen")!
    static let grayGreen : UIColor = UIColor(named:"grayGreen")!

}
