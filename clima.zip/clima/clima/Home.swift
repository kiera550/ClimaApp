//
//  Home.swift
//  clima
//
//  Created by Apple on 7/19/22.
//

import SwiftUI

struct Home: View {
  
   
    var body: some View {
       
        
//        ZStack{
//        Image("backgroundPic")
//              .resizable()
//              .ignoresSafeArea()
        
            ZStack{
                Image ("backgroundPic")
                ZStack{
                Rectangle ()
                    .foregroundColor (Color ("battleshipGrey"))
                    .frame(width: 350.0, height: 220.0)
                    .cornerRadius(15.0)
                    .offset(x: -3.0, y: -150)
                
                Text ("Community Garden Planting")
                        .font(.title)
                    .fontWeight(.heavy)
                    .foregroundColor(Color.white)
                    .offset(x: -55, y: -212.0)
                    .frame(width:300)
                
                Text ("@ Hermitage Street Community Garden                On July 14th from 7 am to 12 pm                             No RVSP                                                                Posted by Catherine Peter")
                    .font(.headline)
                    .fontWeight(.medium)
                    .foregroundColor(Color.white)
                    .offset(x: 20, y: -110)
                    .frame(width:375)
                }
                ZStack{
                Text("Good Morning!")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(Color.white)
                    .multilineTextAlignment(.leading)
                    .offset(x: -60, y: -335.0)
                    
                Text ("Today's Way To Get Involved:")
                        .font(.title2)
                    .fontWeight(.semibold)
                    .foregroundColor(Color.white)
                    .offset(x: -30, y: -290.0)
                }
                Rectangle ()
                    .foregroundColor (Color ("darkSeaGreen"))
                    .frame(width: 370.0, height: 40)
                    .cornerRadius(15.0)
                    .offset(x: 0, y: 10)
                ZStack{
                    Text("For You")
                        .font(.title)
                        .fontWeight(.medium)
                    .foregroundColor(Color.white)
                    .offset(x: -120, y: /*@START_MENU_TOKEN@*/10.0/*@END_MENU_TOKEN@*/)
                }
        
            ZStack{
                Rectangle ()
                    .foregroundColor (Color ("laurelGreen"))
                    .frame(width: 350.0, height: 110.0)
                    .cornerRadius(15.0)
                    .offset(x: -3, y: 100)
                
                Text("Calendar")
                    .offset(x: -130, y: 68)
                
                Text("Reminder: Attending Park Clean Up at Irma C Ruiz today 9am to 12pm")
                    .frame(width: 300)
                    .offset(x: -18, y: 105)
            }
             
                ZStack{
                Rectangle ()
                    .foregroundColor (Color ("laurelGreen"))
                    .frame(width: 350.0, height: 110.0)
                    .cornerRadius(15.0)
                    .offset(x: -3, y: 225)
                    
                    Text("Message from Marnie Jones")
                        .offset(x: -60, y: 195)
                    
                    Text("Hey I was wondering where we are meeting today?")
                        .frame(width: 250)
                        .offset(x:-45,y:235)
                    
                }
                
    }
    
    
    
        
        
        
        
    }
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}
