//
//  climaApp.swift
//  clima
//
//  Created by Apple on 7/18/22.
//

import SwiftUI

@main
struct climaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
