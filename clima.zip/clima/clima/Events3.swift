//
//  Events3.swift
//  clima
//
//  Created by Apple on 8/3/22.
//

import SwiftUI

struct Events3: View {
    var body: some View {
//        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
        
        ZStack{
        
            Image("backgroundPic")
                  .resizable()
                  .ignoresSafeArea()

            Rectangle ()
                .padding(0.0)
                .foregroundColor(Color("grayGreen"))
                .frame (width:350.0, height: 50.0)
                .cornerRadius(/*@START_MENU_TOKEN@*/15.0/*@END_MENU_TOKEN@*/)
                .offset(y:-280)
      
            Rectangle ()
                .foregroundColor (Color ("darkSeaGreen"))
                .frame(width: 350.0, height: 270.0)
                .cornerRadius(15.0)
                .offset( y: -90)
        
            Text ("Youth Summit")
            .font(.title)
            .fontWeight(.bold)
            .foregroundColor(Color.white)
            .multilineTextAlignment(.center)
            .frame(width: 300.0)
            .offset( y:-280)

      Text("Instructions :")
                .fontWeight(.medium)
                .foregroundColor(Color.black)
                .frame(width: 330.0)
                .offset(y:-200)
                .dynamicTypeSize(.xxxLarge)
            Text("@ Dvorak (Anton) Park                                                      On July 25th from 12pm to 4pm                        No RSVP                                                         Posted by Magdeline Pierce                  Meet in front of the main field.   Assignments will be given at 12:10P.M                                                               If lost or confused ask for Magdeline Pierce. ")
                .font(.body)
                .fontWeight(.medium)
                .foregroundColor(Color.black)
                .frame(width: 330.0)
                .offset( y:-80)
                .dynamicTypeSize(.xLarge)
            
            Rectangle ()
                .foregroundColor (Color ("laurelGreen"))
                .frame(width: 350.0, height: 150.0)
                .cornerRadius(15.0)
                .offset(y:145)
            
            Text("Requirements :")
                      .fontWeight(.medium)
                      .foregroundColor(Color.black)
                      .frame(width: 330.0)
                      .offset(y:95)
                      .dynamicTypeSize(.xxxLarge)
            
            Text("- Bring your own shovel                                   - Food will be provided at 4pm                     - 16 years +                                                       - Do not be late")
                .font(.body)
                .fontWeight(.medium)
                .foregroundColor(Color.black)
                .frame(width: 330.0)
                .offset( y:160)

        
        
        
        }
}

struct Events3_Previews: PreviewProvider {
    static var previews: some View {
        Events3()
    }
}
}
